import {
  BadgeInfo,
  BrainCircuit,
  BriefcaseBusiness,
  FileText,
  GraduationCap,
  type LucideIcon,
} from "lucide-react";

export interface NavigationItem {
  label: string;
  path: string;
  icon: LucideIcon;
}

export const mainNavigation: NavigationItem[] = [
  { label: "Resume Builder", path: "/resume", icon: FileText },
  { label: "Jobs", path: "/members", icon: BriefcaseBusiness },
  { label: "Assessments", path: "/analytics", icon: BrainCircuit },
  { label: "Learning", path: "/components", icon: GraduationCap },
];

export const footerNavigation: NavigationItem[] = [
  { label: "About Me", path: "/about", icon: BadgeInfo },
];